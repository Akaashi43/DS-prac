import pandas as pd
from sklearn.preprocessing import LabelEncoder
iris = pd.read_csv("C:/Users/Hithesh/Downloads/New folder/New folder/iris.csv")
print("Original DataFrame:")
print(iris)
le = LabelEncoder()
iris['code'] = le.fit_transform(iris['Species'])
print("\nDataFrame with encoded 'Species' column:")
print(iris)
