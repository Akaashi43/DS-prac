#NAME : TAHENIYAT SHAIKH
#ROLL NO: 22247
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sb
import warnings
from scipy import stats
warnings.filterwarnings('ignore')  
df = sb.load_dataset('mpg')
print(df)
print(df['horsepower'].describe())
print(df['model_year'].describe())
bins = [0, 75, 150, 240]
df['horsepower_new'] = pd.cut(df['horsepower'], bins=bins, labels=['l', 'm', 'h'])
c = df['horsepower_new']
print(c)
ybins = [69, 72, 74, 84]
labels = ['t1', 't2', 't3']
df['model_year_new'] = pd.cut(df['model_year'], bins=ybins, labels=labels)
newyear = df['model_year_new']
print(newyear)
df_chi = pd.crosstab(df['horsepower_new'], df['model_year_new'])
print(df_chi)
chi2, p, dof, expected = stats.chi2_contingency(df_chi)
print(f"Chi-squared: {chi2}, p-value: {p}, Degrees of freedom: {dof}")
print("Expected frequencies:")
print(expected)
