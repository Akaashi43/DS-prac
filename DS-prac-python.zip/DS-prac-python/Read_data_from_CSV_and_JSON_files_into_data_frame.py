#AIM:Read data from CSV and JSON files into a data frame. (1)
# Read data from a csv
import pandas as pd 
df = pd.read_csv('C:/Users/Hithesh/Downloads/New folder/New folder/Sample CSV file for importing contacts.csv') 
print("Our dataset ") 
print(df)
