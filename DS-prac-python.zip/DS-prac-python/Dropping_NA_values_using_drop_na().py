# Dropping NA values using drop na()
import pandas as pd 
df = pd.read_csv('titanic.csv') 
print(df) 
df.head(10) 
print("Dataset after dropping NA values: ")
df.dropna(inplace = True) 
print(df)
