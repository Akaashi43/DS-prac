#NAME : TAHENIYAT SHAIKH
#ROLL NO: 22247
#B. Perform basic data pre-processing tasks such as handling missing valuesand outliers. Code: 
#(1) 
# Replacing NA values using
import pandas as pd 
df = pd.read_csv('C:/New folder/titanic.csv') 
print(df) 
df.head(10) 
print("Dataset after filling NA values with 0 : ")
df2=df.fillna(value=0) 
print(df2)
