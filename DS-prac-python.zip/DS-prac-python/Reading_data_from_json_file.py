# Reading data from json file
import pandas as pd
data = pd.read_json('C:/Users/Hithesh/Downloads/New folder/New folder/dwsample1-json.json')
print(data)
