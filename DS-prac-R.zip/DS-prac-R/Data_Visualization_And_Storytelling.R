#NAME : HITHESH MUDALIYAR
library(ggplot2)
library(dplyr)
library(reshape2)
set.seed(42)
data <- data.frame(
  variable1 = rnorm(1000),
  variable2 = rnorm(1000, mean = 2, sd = 2) + 0.5 * rnorm(1000),
  variable3 = rnorm(1000, mean = -1, sd = 1.5),
  category = sample(c("A", "B", "C", "D"), 1000, replace = TRUE, prob = c(0.4, 0.3, 0.2, 0.1))
)
ggplot(data, aes(x = variable1, y = variable2)) +
  geom_point(alpha = 0.5) +
  ggtitle("Relationship between Variable 1 and Variable 2") +
  xlab("Variable 1") +
  ylab("Variable 2") +
  theme_minimal()
ggplot(data, aes(x = category)) +
  geom_bar(fill = "skyblue") +
  ggtitle("Distribution of Categories") +
  xlab("Category") +
  ylab("Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
numerical_cols <- dplyr::select(data, variable1, variable2, variable3)
correlation_matrix <- cor(numerical_cols)
melted_corr <- melt(correlation_matrix)
ggplot(melted_corr, aes(Var1, Var2, fill = value)) +
  geom_tile() +
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", midpoint = 0) +
  theme_minimal() +
  ggtitle("Correlation Heatmap") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  xlab("") +
  ylab("")
cat("Title: Exploring the Relationship between Variable 1 and Variable 2\n\n")
cat("The scatter plot (Figure 1) shows the relationship between Variable 1 and Variable 2.\n\n")
cat("Scatter Plot\n")
cat("Figure 1: Scatter Plot of Variable 1 and Variable 2\n\n")
cat("To better understand the distribution of the categorical variable 'category', we created a\n")
cat("Bar Chart\n")
cat("Figure 2: Distribution of Categories\n\n")
cat("Additionally, we explored the correlation between numerical variables using a heatmap\n")
cat("Heatmap\n")
cat("Figure 3: Correlation Heatmap\n\n")
cat("In summary, the visualizations and analysis provide insights into the relationships\n")
