#NAME : SUJAL TIWARI
library(dplyr)
iris <- read.csv("C:/New folder/iris.csv")
cat("Original DataFrame:\n")
print(head(iris))
iris$code <- as.integer(factor(iris$Species))
cat("\nDataFrame with encoded 'Species' column:\n")
print(head(iris))
