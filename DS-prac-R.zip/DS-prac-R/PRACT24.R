#NAME : SUJAL TIWARI
library(readr)
df <- read_csv('C:/New folder/titanic.csv')
print(df)
head(df, 10)
cat("Dataset after dropping NA values:\n")
df_cleaned <- na.omit(df)
print(df_cleaned)
