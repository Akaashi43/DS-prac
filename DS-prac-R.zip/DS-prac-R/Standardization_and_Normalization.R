#NAME : SUJAL TIWARI
library(dplyr)
library(scales)
df <- read.csv("C:/New folder/wine.csv", header = FALSE, skip = 1)
colnames(df) <- c("Alcohol", "MalicAcid", "V3", "V4", "V5", "V6", "V7", "V8", "V9", "V10", "V11", "V12", "V13", "V14")
cat("Original DataFrame:\n")
print(head(df))
df_scaled_minmax <- df
df_scaled_minmax$Alcohol <- rescale(df$Alcohol, to = c(0, 1))
df_scaled_minmax$MalicAcid <- rescale(df$MalicAcid, to = c(0, 1))
cat("\nDataframe after MinMax Scaling:\n")
print(df_scaled_minmax)
df_scaled_standard <- df
df_scaled_standard$Alcohol <- scale(df$Alcohol)
df_scaled_standard$MalicAcid <- scale(df$MalicAcid)
cat("\nDataframe after Standard Scaling:\n")
print(df_scaled_standard)

