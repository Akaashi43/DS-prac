#NAME : HITHESH MUDALIYAR
library(MASS)
library(caTools)
data("Boston")
housing_df <- Boston
housing_df$PRICE <- housing_df$medv
X <- housing_df[, c("crim")]  
y <- housing_df$PRICE
set.seed(42)
split <- sample.split(y, SplitRatio = 0.8)
X_train <- subset(X, split == TRUE)
y_train <- subset(y, split == TRUE)
X_test <- subset(X, split == FALSE)
y_test <- subset(y, split == FALSE)
model <- lm(y_train ~ X_train)
predictions <- predict(model, newdata = data.frame(X_train = X_test))
mse <- mean((y_test - predictions)^2)
r2 <- 1 - sum((y_test - predictions)^2) / sum((y_test - mean(y_test))^2)
cat("Mean Squared Error:", mse, "\n")
cat("R-squared:", r2, "\n")
cat("Intercept:", coef(model)[1], "\n")
cat("Coefficient:", coef(model)[2], "\n")

