#NAME : HITHESH MUDALIYAR
library(MLmetrics)
housing <- read.csv("https://raw.githubusercontent.com/jbrownlee/Datasets/master/housing.csv", header = FALSE)
colnames(housing) <- c('Longitude', 'Latitude', 'HousingMedianAge', 'TotalRooms', 'TotalBedrooms',
                       'Population', 'Households', 'MedianIncome', 'MedianHouseValue', 'PRICE')
print(colnames(housing))
housing <- housing[, !is.na(colnames(housing))]
housing$PRICE <- housing$MedianHouseValue
X <- housing[, -ncol(housing)] 
y <- housing$PRICE  

if (anyNA(housing)) {
  housing <- na.omit(housing) 
}
print(colnames(housing))
set.seed(42)
train_indices <- sample(1:nrow(housing), size = 0.8 * nrow(housing))
X_train <- X[train_indices, ]
X_test <- X[-train_indices, ]
y_train <- y[train_indices]
y_test <- y[-train_indices]
model <- lm(PRICE ~ ., data = housing[train_indices, ])
y_pred <- predict(model, newdata = X_test)
mse <- mean((y_test - y_pred)^2)
r2 <- R2_Score(y_test, y_pred)
cat("Mean Squared Error:", mse, "\n")
cat("R-squared:", r2, "\n")
cat("Intercept:", coef(model)[1], "\n")
cat("Coefficients:", coef(model)[-1], "\n")

