#NAME : HITHESH MUDALIYAR
library(ggplot2)
library(datasets)
data(iris)
iris_df <- iris
X_scaled <- scale(iris_df[, 1:4])
pca <- prcomp(X_scaled)
explained_variance_ratio <- summary(pca)$importance[2, ]
cumulative_variance_ratio <- cumsum(explained_variance_ratio)
plot(cumulative_variance_ratio, type = 'b', 
     xlab = 'Number of Principal Components', 
     ylab = 'Cumulative Explained Variance Ratio', 
     main = 'Explained Variance Ratio', 
     col = 'blue', pch = 19)
grid()
n_components <- which(cumulative_variance_ratio >= 0.95)[1]
cat("Number of principal components to explain 95% variance:", n_components, "\n")
pca_reduced <- as.data.frame(pca$x[, 1:n_components])
ggplot(pca_reduced, aes(x = PC1, y = PC2, color = iris_df$Species)) +
  geom_point(alpha = 0.5) +
  labs(title = "Data in Reduced-dimensional Space", 
       x = "Principal Component 1", 
       y = "Principal Component 2") +
  scale_color_viridis_d() +
  theme_minimal()

