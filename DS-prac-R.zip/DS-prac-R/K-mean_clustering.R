#NAME : PREM PRAJAPATI
library(dplyr)
library(tidyr)
library(ggplot2)
library(cluster)
library(purrr)
data <- read.csv("C:/New folder/Wholesale customers data.csv")
head(data)
categorical_features <- c("Channel", "Region")
continuous_features <- c("Fresh", "Milk", "Grocery", "Frozen", "Detergents_Paper", "Delicassen")
data <- data[, !(names(data) %in% categorical_features)]
constant_columns <- sapply(data, function(x) length(unique(x)) == 1)
data <- data[, !constant_columns]
data <- bind_cols(data, purrr::map_dfc(categorical_features, ~model.matrix(~ . - 1, data = data)))
print(colnames(data))
continuous_features_in_data <- intersect(continuous_features, colnames(data))
data_scaled <- scale(data[, continuous_features_in_data])
if(any(is.na(data_scaled)) | any(sapply(data_scaled, is.infinite))) {
  print("Warning: NaN or Inf values detected after scaling!")
}
sum_of_squared_distances <- numeric()
K <- 1:min(nrow(data_scaled), 10)  # Define range for k

for (k in K) {
  km <- tryCatch({
    kmeans(data_scaled, centers = k, nstart = 25)
  }, error = function(e) {
    print(paste("Error with k =", k, ": ", e$message))
    return(NULL)  
  })
  
  if (!is.null(km)) {
    sum_of_squared_distances[k] <- km$tot.withinss
  }
}
print(sum_of_squared_distances)
sum_of_squared_distances <- sum_of_squared_distances[!is.na(sum_of_squared_distances)]
if(length(sum_of_squared_distances) > 0) {
  elbow_data <- data.frame(K = K[1:length(sum_of_squared_distances)], Sum_of_Squared_Distances = sum_of_squared_distances)
  ggplot(elbow_data, aes(x = K, y = Sum_of_Squared_Distances)) +
    geom_line() +
    geom_point() +
    labs(x = "k", y = "Sum of Squared Distances", title = "Elbow Method for Optimal k")
}  

