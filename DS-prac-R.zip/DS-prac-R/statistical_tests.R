#NAME : SUJAL TIWARI
library(ggplot2)
set.seed(42)
sample1 <- rnorm(30, mean = 10, sd = 2) 
sample2 <- rnorm(30, mean = 12, sd = 2) 
t_test_result <- t.test(sample1, sample2)
alpha <- 0.05
cat("Results of Two-Sample t test:\n")
cat("T-statistic:", t_test_result$statistic, "\n")
cat("P-value:", t_test_result$p.value, "\n")
cat("Degrees of Freedom:", t_test_result$parameter, "\n")
df <- data.frame(
  value = c(sample1, sample2),
  sample = rep(c("Sample 1", "Sample 2"), each = 30)
)

ggplot(df, aes(x = value, fill = sample)) +
  geom_histogram(position = "identity", alpha = 0.5, bins = 15) +
  geom_vline(aes(xintercept = mean(sample1)), color = "blue", linetype = "dashed", linewidth = 1) +  # Replaced 'size' with 'linewidth'
  geom_vline(aes(xintercept = mean(sample2)), color = "orange", linetype = "dashed", linewidth = 1) +  # Replaced 'size' with 'linewidth'
  labs(title = "Distributions of Sample 1 and Sample 2", x = "Values", y = "Frequency") +
  theme_minimal() +
  scale_fill_manual(values = c("blue", "orange"))

if (t_test_result$p.value < alpha) {
  df_x <- seq(min(c(sample1, sample2)), max(c(sample1, sample2)), length.out = 1000)
  df_y <- dt(df_x, df = t_test_result$parameter)
  
  critical_t <- qt(1 - alpha / 2, df = t_test_result$parameter)  # Two-tailed test
  ggplot(df, aes(x = value, fill = sample)) +
    geom_histogram(position = "identity", alpha = 0.5, bins = 15) +
    geom_vline(aes(xintercept = mean(sample1)), color = "blue", linetype = "dashed", size = 1) +
    geom_vline(aes(xintercept = mean(sample2)), color = "orange", linetype = "dashed", size = 1) +
    geom_area(data = data.frame(x = df_x, y = df_y),
              aes(x = x, y = y), fill = "red", alpha = 0.3) +
    labs(title = "Distributions of Sample 1 and Sample 2", x = "Values", y = "Frequency") +
    theme_minimal() +
    scale_fill_manual(values = c("blue", "orange"))
  
  cat("Critical Region Highlighted for T-statistic:", t_test_result$statistic, "\n")
}
if (t_test_result$p.value < alpha) {
  if (mean(sample1) > mean(sample2)) {
    cat("Conclusion: There is significant evidence to reject the null hypothesis.\n")
    cat("Interpretation: The mean of Sample 1 is significantly higher than that of Sample 2.\n")
  } else {
    cat("Conclusion: There is significant evidence to reject the null hypothesis.\n")
    cat("Interpretation: The mean of Sample 2 is significantly higher than that of Sample 1.\n")
  }
} else {
  cat("Conclusion: Fail to reject the null hypothesis.\n")
  cat("Interpretation: There is not enough evidence to claim a significant difference between the means.\n")
}

