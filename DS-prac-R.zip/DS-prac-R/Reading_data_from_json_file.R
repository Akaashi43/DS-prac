#NAME : SUJAL TIWARI
install.packages("jsonlite")
library(jsonlite)
data <- fromJSON("C:/New folder/dwsample1-json.json")
print(data)
