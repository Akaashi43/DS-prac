#NAME : HITHESH MUDALIYAR
library(datasets)
library(caret)
library(rpart)
library(Metrics)
library(glmnet)
data(iris)
iris_binary <- subset(iris, Species != "virginica")
X <- iris_binary[, 1:4]
y <- iris_binary[, 5]
set.seed(42)
trainIndex <- createDataPartition(y, p = 0.8, list = FALSE)
X_train <- X[trainIndex, ]
y_train <- y[trainIndex]
X_test <- X[-trainIndex, ]
y_test <- y[-trainIndex]
y_train_numeric <- ifelse(y_train == "setosa", 1, 0)
y_test_numeric <- ifelse(y_test == "setosa", 1, 0)
logistic_model_ridge <- glmnet(as.matrix(X_train), y_train_numeric, alpha = 0, lambda = 0.1)  # Ridge (alpha = 0)
y_pred_logistic_ridge_prob <- predict(logistic_model_ridge, newx = as.matrix(X_test), type = "response", s = 0.1)
y_pred_logistic_ridge <- ifelse(y_pred_logistic_ridge_prob > 0.5, "setosa", "versicolor")
cat("Logistic Regression (Ridge) Metrics\n")
cat("Accuracy:", sum(y_pred_logistic_ridge == y_test) / length(y_test), "\n")
cat("Precision:", precision(y_test_numeric, as.numeric(y_pred_logistic_ridge == "setosa")), "\n")
cat("Recall:", recall(y_test_numeric, as.numeric(y_pred_logistic_ridge == "setosa")), "\n")
cat("\nClassification Report:\n")
print(confusionMatrix(factor(y_pred_logistic_ridge), factor(y_test)))
decision_tree_model <- rpart(Species ~ ., data = iris_binary[trainIndex, ], method = "class")
y_pred_tree <- predict(decision_tree_model, newdata = X_test, type = "class")
cat("\nDecision Tree Metrics\n")
cat("Accuracy:", sum(y_pred_tree == y_test) / length(y_test), "\n")
cat("Precision:", precision(y_test_numeric, as.numeric(y_pred_tree == "setosa")), "\n")
cat("Recall:", recall(y_test_numeric, as.numeric(y_pred_tree == "setosa")), "\n")
cat("\nClassification Report:\n")
print(confusionMatrix(factor(y_pred_tree), factor(y_test)))

