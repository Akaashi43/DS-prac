#NAME : SUJAL TIWARI
library(readr)
df <- read_csv('C:/New folder/titanic.csv')
print(df)
head(df, 10)
cat("Dataset after filling NA values with 0:\n")
df2 <- df
df2[is.na(df2)] <- 0
print(df2)
