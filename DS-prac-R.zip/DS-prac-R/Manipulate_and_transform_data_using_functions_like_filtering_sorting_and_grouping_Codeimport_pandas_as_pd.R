#NAME : SUJAL TIWARI
library(dplyr)
iris <- read.csv("C:/New folder/iris.csv")
setosa <- subset(iris, Species == "setosa")
cat("Setosa samples:\n")
head(setosa)
sorted_iris <- iris %>% arrange(desc(SepalLengthCm))
cat("\nSorted iris dataset:\n")
head(sorted_iris)
grouped_species <- iris %>% group_by(Species) %>% summarise(across(where(is.numeric), mean))
cat("\nMean measurements for each species:\n")
print(grouped_species)

