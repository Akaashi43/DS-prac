#NAME : TAHENIYAT SHAIKH
library(readr)
df=read_csv("C:/New folder/Sample CSV file for importing contacts.csv")
print("Our dataset:")
print(df)

