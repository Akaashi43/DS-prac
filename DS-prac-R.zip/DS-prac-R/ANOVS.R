#NAME : SUJAL TIWARI
group1 <- c(23, 25, 29, 34, 30)
group2 <- c(19, 20, 22, 24, 25)
group3 <- c(15, 18, 20, 21, 17)
group4 <- c(28, 24, 26, 30, 29)

# Combine data into a data frame
data <- data.frame(
  value = c(group1, group2, group3, group4),
  group = factor(rep(c("Gro p1", "Group2", "Group3", "Group4"), each = 5))
)

# Perform one-way ANOVA
anova_result <- aov(value ~ group, data = data)
summary(anova_result)

# Perform Tukey-Kramer post-hoc test
tukey_result <- TukeyHSD(anova_result)
print(tukey_result)
